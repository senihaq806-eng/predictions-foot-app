import { useMemo, useState } from "react";
import Link from "next/link";

const PITCH = "#132A1D";

const FILTRES = [
  { id: "tous", label: "Tous" },
  { id: "domicile", label: "Victoire domicile" },
  { id: "nul", label: "Match nul" },
  { id: "exterieur", label: "Victoire extérieur" },
  { id: "plus15", label: "Plus de 1,5" },
  { id: "plus25", label: "Plus de 2,5" },
  { id: "moins25", label: "Moins de 2,5" },
  { id: "btts_oui", label: "BTTS Oui" },
  { id: "btts_non", label: "BTTS Non" },
  { id: "haute_confiance", label: "Haute confiance" },
];

function dateEnYMD(d) {
  return d.toISOString().slice(0, 10);
}

function correspondAuFiltre(opportunite, filtre) {
  if (filtre === "tous") return true;
  if (filtre === "haute_confiance") return opportunite.niveauConfiance === "élevée";
  if (filtre === "domicile") return opportunite.predictionRetenue.startsWith("Victoire") && !opportunite.predictionRetenue.includes(opportunite.equipeB);
  if (filtre === "exterieur") return opportunite.predictionRetenue === `Victoire ${opportunite.equipeB}`;
  if (filtre === "nul") return opportunite.predictionRetenue === "Match nul";
  if (filtre === "plus15") return opportunite.predictionRetenue === "Plus de 1,5 but";
  if (filtre === "plus25") return opportunite.predictionRetenue === "Plus de 2,5 buts";
  if (filtre === "btts_oui") return opportunite.predictionRetenue === "Les deux équipes marquent";
  return true;
}

export default function Accueil() {
  const aujourdHui = new Date();
  const demain = new Date(Date.now() + 86400000);
  const apresDemain = new Date(Date.now() + 2 * 86400000);

  const [date, setDate] = useState(dateEnYMD(aujourdHui));
  const [matchs, setMatchs] = useState(null);
  const [chargement, setChargement] = useState(false);
  const [erreur, setErreur] = useState(null);

  const [classement, setClassement] = useState(null);
  const [chargementClassement, setChargementClassement] = useState(false);
  const [erreurClassement, setErreurClassement] = useState(null);
  const [filtreActif, setFiltreActif] = useState("tous");
  const [championnat, setChampionnat] = useState("tous");

  async function analyser() {
    setChargement(true);
    setErreur(null);
    setMatchs(null);
    setClassement(null);
    try {
      const res = await fetch(`/api/matches?date=${date}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.erreur || "Erreur inconnue");
      setMatchs(json.matchs);
    } catch (e) {
      setErreur(e.message);
    } finally {
      setChargement(false);
    }
  }

  async function lancerClassement() {
    setChargementClassement(true);
    setErreurClassement(null);
    try {
      const res = await fetch(`/api/top-predictions?date=${date}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.erreur || "Erreur inconnue");
      setClassement(json);
    } catch (e) {
      setErreurClassement(e.message);
    } finally {
      setChargementClassement(false);
    }
  }

  const championnats = useMemo(() => {
    if (!matchs) return [];
    return [...new Set(matchs.map((m) => m.competition).filter(Boolean))];
  }, [matchs]);

  const opportunitesFiltrees = useMemo(() => {
    if (!classement?.classement) return [];
    return classement.classement
      .filter((o) => championnat === "tous" || o.competition === championnat)
      .filter((o) => correspondAuFiltre(o, filtreActif));
  }, [classement, filtreActif, championnat]);

  return (
    <div className="min-h-screen">
      <div style={{ backgroundColor: PITCH }} className="py-10 px-4">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-2xl font-bold text-white mb-1">⚽ Prédictions Football</h1>
          <p className="text-sm mb-6" style={{ color: "#C9D0BE" }}>
            Sélectionnez une date — matchs, statistiques et pronostics sont récupérés automatiquement.
          </p>

          <div className="flex flex-wrap gap-2 mb-3">
            <BoutonRapide label="Aujourd'hui" onClick={() => setDate(dateEnYMD(aujourdHui))} />
            <BoutonRapide label="Demain" onClick={() => setDate(dateEnYMD(demain))} />
            <BoutonRapide label="Après-demain" onClick={() => setDate(dateEnYMD(apresDemain))} />
          </div>

          <div className="flex gap-2">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="rounded px-3 py-2 text-sm" />
            <button onClick={analyser} disabled={chargement} className="px-5 py-2 rounded text-sm font-semibold bg-white" style={{ color: PITCH }}>
              {chargement ? "Analyse..." : "🔍 Analyser les matchs"}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        {erreur && <MessageErreur erreur={erreur} />}

        {matchs && matchs.length === 0 && <p className="text-sm text-neutral-500">Aucun match trouvé pour cette date.</p>}

        {matchs && matchs.length > 0 && (
          <>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-neutral-500">
                {matchs.length} match{matchs.length > 1 ? "s" : ""} trouvé{matchs.length > 1 ? "s" : ""}
              </h2>
              <button
                onClick={lancerClassement}
                disabled={chargementClassement}
                className="text-xs px-4 py-2 rounded-full font-semibold"
                style={{ backgroundColor: "#C79A3C", color: "#1A1D1B" }}
                title="Analyse chaque match du jour pour établir un classement — consomme un appel API par match"
              >
                {chargementClassement ? "Analyse en cours…" : "🔥 Classer les meilleures opportunités"}
              </button>
            </div>

            {erreurClassement && <MessageErreur erreur={erreurClassement} />}

            {classement && (
              <div className="mb-8">
                <h3 className="text-base font-bold mb-2">🔥 Meilleures prédictions du jour</h3>
                {classement.matchsIgnores > 0 && (
                  <p className="text-xs text-neutral-500 mb-2">
                    {classement.matchsIgnores} match(s) non analysé(s) pour préserver le quota API restant ({classement.appelsRestantsApres} appels restants aujourd'hui).
                  </p>
                )}

                <div className="flex flex-wrap gap-1.5 mb-4">
                  <select value={championnat} onChange={(e) => setChampionnat(e.target.value)} className="text-xs rounded border px-2 py-1.5">
                    <option value="tous">Tous les championnats</option>
                    {championnats.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  {FILTRES.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setFiltreActif(f.id)}
                      className="text-xs px-2.5 py-1.5 rounded-full border"
                      style={{
                        backgroundColor: filtreActif === f.id ? PITCH : "white",
                        color: filtreActif === f.id ? "white" : "#5C6152",
                        borderColor: filtreActif === f.id ? PITCH : "#DCDFD2",
                      }}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>

                <div className="space-y-2">
                  {opportunitesFiltrees.length === 0 && (
                    <p className="text-sm text-neutral-400">Aucune opportunité ne correspond à ce filtre.</p>
                  )}
                  {opportunitesFiltrees.map((o, i) => (
                    <Link key={o.fixtureId} href={`/match/${o.fixtureId}`} className="block">
                      <div className="rounded-lg border border-neutral-200 bg-white p-4 hover:border-neutral-400 transition-colors flex justify-between items-center">
                        <div>
                          <div className="text-xs text-neutral-400">#{i + 1} — {o.competition}</div>
                          <div className="font-bold">{o.equipeA} vs {o.equipeB}</div>
                          <div className="text-sm mt-1">
                            {o.predictionRetenue} — <span className="font-semibold">{o.probabilite}%</span>
                          </div>
                        </div>
                        <span
                          className="text-xs px-2.5 py-1 rounded-full whitespace-nowrap"
                          style={{
                            backgroundColor: o.niveauConfiance === "élevée" ? "#E5F1E8" : o.niveauConfiance === "moyenne" ? "#FBF2DF" : "#F5E5E3",
                            color: o.niveauConfiance === "élevée" ? "#3C7A4E" : o.niveauConfiance === "moyenne" ? "#8A6D1F" : "#A6493C",
                          }}
                        >
                          Confiance {o.niveauConfiance}
                        </span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            <h2 className="text-sm font-semibold uppercase tracking-wide text-neutral-500 mb-3">Matchs du jour</h2>
            <div className="space-y-3">
              {matchs.map((m) => (
                <Link key={m.id} href={`/match/${m.id}`} className="block">
                  <div className="rounded-lg border border-neutral-200 bg-white p-4 hover:border-neutral-400 transition-colors">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-bold">{m.equipeA} vs {m.equipeB}</div>
                        <div className="text-xs text-neutral-500 mt-1">
                          {m.competition} ({m.pays}) — {new Date(m.date).toLocaleString("fr-FR")}
                        </div>
                      </div>
                      <span className="text-xs px-3 py-1.5 rounded-full bg-neutral-100">Voir l'analyse →</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            <div className="mt-6">
              <Link href="/historique" className="text-xs text-neutral-500 hover:underline">Voir l'historique des pronostics →</Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function MessageErreur({ erreur }) {
  return (
    <div className="rounded bg-red-50 text-red-700 text-sm px-4 py-3 mb-4">
      {erreur}
      {erreur.includes("Clé API") && (
        <div className="mt-1 text-xs">Voir le fichier .env.local.example à la racine du projet pour configurer votre clé.</div>
      )}
    </div>
  );
}

function BoutonRapide({ label, onClick }) {
  return (
    <button onClick={onClick} className="text-xs px-3 py-1.5 rounded-full bg-white/10 text-white hover:bg-white/20">
      {label}
    </button>
  );
}
