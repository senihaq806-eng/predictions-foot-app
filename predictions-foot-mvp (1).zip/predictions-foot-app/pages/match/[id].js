import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import { meilleureOpportunite } from "../../lib/predictionEngine";

const COULEUR_NIVEAU = {
  "élevée": { bg: "#E5F1E8", fg: "#3C7A4E" },
  moyenne: { bg: "#FBF2DF", fg: "#8A6D1F" },
  faible: { bg: "#F5E5E3", fg: "#A6493C" },
};

export default function DetailMatch() {
  const router = useRouter();
  const { id } = router.query;
  const [donnees, setDonnees] = useState(null);
  const [erreur, setErreur] = useState(null);

  useEffect(() => {
    if (!id) return;
    fetch(`/api/match-analysis?fixtureId=${id}`)
      .then(async (res) => {
        const json = await res.json();
        if (!res.ok) throw new Error(json.erreur);
        setDonnees(json);
        if (json.analyse) sauvegarderDansHistorique(json);
      })
      .catch((e) => setErreur(e.message));
  }, [id]);

  if (erreur) return <MessagePage><p className="text-red-700 text-sm">{erreur}</p></MessagePage>;
  if (!donnees) return <MessagePage><p className="text-sm text-neutral-500">Analyse en cours…</p></MessagePage>;

  // Match reporté / annulé / abandonné : le backend renvoie fixture + statutSpecial, sans analyse.
  if (donnees.statutSpecial) {
    return (
      <MessagePage>
        <h1 className="text-xl font-bold mb-2">{donnees.fixture.equipeA} vs {donnees.fixture.equipeB}</h1>
        <p className="text-sm text-neutral-600">
          {donnees.statutSpecial} — aucune prédiction n'est calculée pour un match qui ne se jouera pas comme prévu.
        </p>
      </MessagePage>
    );
  }

  const { fixture, analyse } = donnees;
  const p = analyse.predictionPrincipale;
  const couleurNiveau = COULEUR_NIVEAU[analyse.niveauConfiance] || COULEUR_NIVEAU.moyenne;

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <Link href="/" className="text-xs text-neutral-500 hover:underline">← Retour</Link>

      <h1 className="text-2xl font-bold mt-3">{fixture.equipeA} vs {fixture.equipeB}</h1>
      <p className="text-sm text-neutral-500 mb-6">
        {fixture.competition} · {new Date(fixture.date).toLocaleString("fr-FR")}
        {fixture.stade ? ` · ${fixture.stade}` : ""}
      </p>

      <Section titre="Prédiction principale (1X2)">
        <div className="flex rounded-lg overflow-hidden h-9 text-sm font-semibold text-white">
          <div style={{ width: `${p.victoireDomicile}%`, backgroundColor: "#3C7A4E" }} className="flex items-center justify-center">
            {p.victoireDomicile >= 10 ? `${p.victoireDomicile}%` : ""}
          </div>
          <div style={{ width: `${p.nul}%`, backgroundColor: "#C79A3C" }} className="flex items-center justify-center">
            {p.nul >= 10 ? `${p.nul}%` : ""}
          </div>
          <div style={{ width: `${p.victoireExterieur}%`, backgroundColor: "#A6493C" }} className="flex items-center justify-center">
            {p.victoireExterieur >= 10 ? `${p.victoireExterieur}%` : ""}
          </div>
        </div>
        <div className="flex justify-between text-xs text-neutral-500 mt-1">
          <span>{fixture.equipeA}</span><span>Nul</span><span>{fixture.equipeB}</span>
        </div>

        <div className="mt-4 flex items-center gap-3">
          <span
            className="text-sm font-bold px-3 py-1.5 rounded-full"
            style={{ backgroundColor: couleurNiveau.bg, color: couleurNiveau.fg }}
          >
            Confiance {analyse.confiance}% — {analyse.niveauConfiance}
          </span>
        </div>
        <p className="text-xs text-neutral-500 mt-2">{analyse.explicationConfiance}</p>
      </Section>

      <Section titre="Buts et BTTS">
        <ul className="text-sm space-y-1">
          <li>Plus de 1,5 but : {analyse.autresPredictions.plus15Buts}%</li>
          <li>Plus de 2,5 buts : {analyse.autresPredictions.plus25Buts}%</li>
          <li>Moins de 2,5 buts : {analyse.autresPredictions.moins25Buts}%</li>
          <li>Les deux équipes marquent : {analyse.autresPredictions.btts}%</li>
          <li>Score probable : <span className="font-semibold">{analyse.autresPredictions.scoreProbable}</span></li>
        </ul>
      </Section>

      <Section titre="Forme récente (5 derniers matchs réels)">
        <FormeEquipe titre={fixture.equipeA} forme={analyse.formeRecente[fixture.equipeA]} />
        <FormeEquipe titre={fixture.equipeB} forme={analyse.formeRecente[fixture.equipeB]} />
      </Section>

      <Section titre="Classement">
        <ClassementEquipe titre={fixture.equipeA} valeur={analyse.classement[fixture.equipeA]} />
        <ClassementEquipe titre={fixture.equipeB} valeur={analyse.classement[fixture.equipeB]} />
      </Section>

      <Section titre="Confrontations directes">
        {typeof analyse.h2hResume === "string" ? (
          <p className="text-sm text-neutral-500">{analyse.h2hResume}</p>
        ) : (
          <p className="text-sm">
            Sur les {analyse.h2hResume.matchsAnalyses} dernières rencontres : {analyse.h2hResume.victoiresA} victoire(s) {fixture.equipeA},{" "}
            {analyse.h2hResume.nuls} nul(s), {analyse.h2hResume.victoiresB} victoire(s) {fixture.equipeB}.
            <span className="block text-xs text-neutral-400 mt-1">Utilisé comme facteur secondaire uniquement.</span>
          </p>
        )}
      </Section>

      <Section titre="Blessures / absences signalées">
        <BlessuresListe titre={fixture.equipeA} valeur={analyse.blessures[fixture.equipeA]} />
        <BlessuresListe titre={fixture.equipeB} valeur={analyse.blessures[fixture.equipeB]} />
      </Section>

      <Section titre="Pourquoi cette prédiction ?">
        <p className="text-sm text-neutral-600">{analyse.explication}</p>
        {analyse.donneesManquantes.length > 0 && (
          <ul className="text-xs text-neutral-500 list-disc pl-4 mt-2">
            {analyse.donneesManquantes.map((m, i) => <li key={i}>{m}</li>)}
          </ul>
        )}
      </Section>

      <p className="text-xs text-neutral-400 mt-6 italic">{analyse.avertissement}</p>
    </div>
  );
}

function MessagePage({ children }) {
  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <Link href="/" className="text-xs text-neutral-500 hover:underline">← Retour</Link>
      <div className="mt-4">{children}</div>
    </div>
  );
}

function Section({ titre, children }) {
  return (
    <div className="mb-6">
      <h2 className="text-xs font-semibold uppercase tracking-wide text-neutral-500 mb-2">{titre}</h2>
      {children}
    </div>
  );
}

function FormeEquipe({ titre, forme }) {
  if (typeof forme === "string") {
    return <div className="text-sm mb-1"><span className="font-semibold">{titre} : </span>{forme}</div>;
  }
  return (
    <div className="text-sm mb-2">
      <span className="font-semibold">{titre} : </span>
      {forme.victoires}V {forme.nuls}N {forme.defaites}D sur {forme.matchsAnalyses} match(s) — moyenne {forme.moyenneButsMarques.toFixed(1)} but(s) marqué(s), {forme.moyenneButsEncaisses.toFixed(1)} encaissé(s)
    </div>
  );
}

function ClassementEquipe({ titre, valeur }) {
  return (
    <div className="text-sm mb-1">
      <span className="font-semibold">{titre} : </span>
      {typeof valeur === "string" ? valeur : `${valeur.rang}ᵉ place, ${valeur.points} points`}
    </div>
  );
}

function BlessuresListe({ titre, valeur }) {
  return (
    <div className="text-sm mb-1">
      <span className="font-semibold">{titre} : </span>
      {Array.isArray(valeur) ? (valeur.length ? valeur.join(", ") : "Aucune signalée") : valeur}
    </div>
  );
}

// Historique local (voir pages/historique.js) — pas de base de données pour ce MVP,
// on garde une trace des matchs consultés dans le navigateur de l'utilisateur.
// Architecture prête pour être remplacée par un vrai stockage partagé : il suffirait
// de remplacer ces deux fonctions localStorage par des appels à une route /api/historique.
function sauvegarderDansHistorique({ fixture, analyse }) {
  try {
    const cle = "historique_pronostics";
    const existant = JSON.parse(localStorage.getItem(cle) || "[]");
    if (existant.some((e) => e.fixtureId === fixture.id)) return;

    const meilleure = meilleureOpportunite(analyse, fixture.equipeA, fixture.equipeB);
    const entree = {
      fixtureId: fixture.id,
      equipeA: fixture.equipeA,
      equipeB: fixture.equipeB,
      date: fixture.date,
      prediction: analyse.predictionPrincipale,
      predictionRetenue: meilleure.libelle,
      probabilite: meilleure.probabilite,
      confiance: analyse.confiance,
      niveauConfiance: analyse.niveauConfiance,
      consulteLe: new Date().toISOString(),
      resultatVerifie: false,
    };
    localStorage.setItem(cle, JSON.stringify([entree, ...existant].slice(0, 200)));
  } catch {
    // stockage local indisponible : on continue sans historique
  }
}
