import { useEffect, useState } from "react";
import Link from "next/link";

const CLE = "historique_pronostics";

export default function Historique() {
  const [entrees, setEntrees] = useState([]);

  useEffect(() => {
    try {
      setEntrees(JSON.parse(localStorage.getItem(CLE) || "[]"));
    } catch {
      setEntrees([]);
    }
  }, []);

  function sauvegarder(liste) {
    setEntrees(liste);
    localStorage.setItem(CLE, JSON.stringify(liste));
  }

  async function verifier(entree) {
    const res = await fetch(`/api/verify?fixtureId=${entree.fixtureId}`);
    const json = await res.json();
    if (!json.termine) {
      alert("Ce match n'est pas encore terminé.");
      return;
    }
    const correcte = evaluerPrediction(entree, json);
    const maj = entrees.map((e) =>
      e.fixtureId === entree.fixtureId
        ? { ...e, resultatVerifie: true, resultatReel: json, correcte }
        : e
    );
    sauvegarder(maj);
  }

  // Compare le résultat réel au type de pari retenu (1X2, over/under ou BTTS) —
  // pas seulement à la victoire/nul/défaite, puisque la meilleure opportunité
  // d'un match peut être un autre marché que le 1X2.
  function evaluerPrediction(entree, resultat) {
    const totalButs = resultat.butsA + resultat.butsB;
    const libelle = entree.predictionRetenue || favoriDe(entree.prediction);
    if (libelle === "Match nul") return resultat.issue === "nul";
    if (libelle === `Victoire ${entree.equipeA}`) return resultat.issue === "domicile";
    if (libelle === `Victoire ${entree.equipeB}`) return resultat.issue === "exterieur";
    if (libelle === "Plus de 1,5 but") return totalButs > 1.5;
    if (libelle === "Plus de 2,5 buts") return totalButs > 2.5;
    if (libelle === "Les deux équipes marquent") return resultat.butsA > 0 && resultat.butsB > 0;
    return null;
  }

  function favoriDe(p) {
    if (p.victoireDomicile >= p.nul && p.victoireDomicile >= p.victoireExterieur) return "domicile";
    if (p.victoireExterieur >= p.nul) return "exterieur";
    return "nul";
  }

  const total = entrees.filter((e) => e.resultatVerifie).length;
  const correctes = entrees.filter((e) => e.correcte).length;

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <Link href="/" className="text-xs text-neutral-500 hover:underline">← Retour</Link>
      <h1 className="text-2xl font-bold mt-3 mb-1">Historique des pronostics</h1>
      <p className="text-sm text-neutral-500 mb-6">
        Stocké localement dans votre navigateur pour ce MVP (pas encore de base de données partagée).
        {total > 0 && ` Sur ${total} match(s) vérifié(s) : ${correctes} pronostic(s) correct(s).`}
      </p>

      {entrees.length === 0 && (
        <p className="text-sm text-neutral-400">Aucun match consulté pour l'instant.</p>
      )}

      <div className="space-y-3">
        {entrees.map((e) => (
          <div key={e.fixtureId} className="rounded-lg border border-neutral-200 bg-white p-4">
            <div className="flex justify-between items-start">
              <div>
                <div className="font-bold">{e.equipeA} vs {e.equipeB}</div>
                <div className="text-xs text-neutral-500">
                  {new Date(e.date).toLocaleDateString("fr-FR")}
                </div>
                {e.predictionRetenue && (
                  <div className="text-sm mt-1">
                    {e.predictionRetenue} — <span className="font-semibold">{e.probabilite}%</span>
                    <span className="text-xs text-neutral-400"> · confiance {e.confiance}%</span>
                  </div>
                )}
              </div>
              {!e.resultatVerifie ? (
                <button
                  onClick={() => verifier(e)}
                  className="text-xs px-3 py-1.5 rounded-full bg-neutral-100 hover:bg-neutral-200"
                >
                  Vérifier le résultat
                </button>
              ) : (
                <span
                  className="text-xs px-3 py-1.5 rounded-full font-semibold"
                  style={{
                    backgroundColor: e.correcte ? "#E5F1E8" : "#F5E5E3",
                    color: e.correcte ? "#3C7A4E" : "#A6493C",
                  }}
                >
                  {e.correcte ? "✓ Correct" : "✗ Incorrect"} ({e.resultatReel.butsA}-{e.resultatReel.butsB})
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
