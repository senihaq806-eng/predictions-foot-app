const {
  ErreurApiSportive,
  getFixtureById,
  getTeamStatistics,
  getHeadToHead,
  getInjuries,
  getLastFixtures,
  getStandings,
} = require("../../lib/apiFootball");
const { analyserMatch } = require("../../lib/predictionEngine");
const cache = require("../../lib/cache");

const TTL_30_MIN = 30 * 60 * 1000;

export default async function handler(req, res) {
  const { fixtureId } = req.query;
  if (!fixtureId) {
    return res.status(400).json({ erreur: "Le paramètre 'fixtureId' est requis." });
  }

  try {
    const { data, depuisCache } = await cache.wrap(`analyse:${fixtureId}`, TTL_30_MIN, () =>
      construireAnalyse(fixtureId)
    );
    res.status(200).json({ ...data, depuisCache });
  } catch (err) {
    repondreErreur(res, err);
  }
}

async function construireAnalyse(fixtureId) {
  const brut = await getFixtureById(fixtureId);
  if (!brut) throw new Error("Match introuvable.");

  const statut = brut.fixture.status?.short;
  if (["PST", "CANC", "ABD"].includes(statut)) {
    return {
      fixture: { equipeA: brut.teams.home.name, equipeB: brut.teams.away.name },
      statutSpecial: statut === "PST" ? "Match reporté" : statut === "CANC" ? "Match annulé" : "Match abandonné",
      analyse: null,
    };
  }

  const fixture = {
    id: brut.fixture.id,
    equipeA: brut.teams.home.name,
    equipeAId: brut.teams.home.id,
    equipeB: brut.teams.away.name,
    equipeBId: brut.teams.away.id,
    date: brut.fixture.date,
    competition: brut.league?.name,
    leagueId: brut.league?.id,
    season: brut.league?.season,
    stade: brut.fixture.venue?.name || null,
  };

  // Chaque appel est tenté indépendamment : une source indisponible ne bloque
  // pas les autres — le moteur de prédiction se charge de marquer clairement
  // ce qui manque plutôt que d'inventer une valeur.
  const [statsA, statsB, lastFixturesA, lastFixturesB, h2h, blessuresMatch, standings] = await Promise.all([
    essayer(() => getTeamStatistics(fixture.equipeAId, fixture.leagueId, fixture.season)),
    essayer(() => getTeamStatistics(fixture.equipeBId, fixture.leagueId, fixture.season)),
    essayer(() => getLastFixtures(fixture.equipeAId, 5), []),
    essayer(() => getLastFixtures(fixture.equipeBId, 5), []),
    essayer(() => getHeadToHead(fixture.equipeAId, fixture.equipeBId, 5), []),
    essayer(() => getInjuries(fixtureId), []),
    essayer(() => getStandings(fixture.leagueId, fixture.season), null),
  ]);

  // Les derniers matchs incluent parfois la rencontre du jour elle-même si
  // elle a déjà commencé : on l'exclut pour ne comparer qu'à des matchs passés.
  const exclureMatchCourant = (liste) => (liste || []).filter((f) => f.fixture.id !== Number(fixtureId));

  const blessuresA = (blessuresMatch || []).filter((b) => b.team?.id === fixture.equipeAId);
  const blessuresB = (blessuresMatch || []).filter((b) => b.team?.id === fixture.equipeBId);

  const standingsA = trouverEquipeClassement(standings, fixture.equipeAId);
  const standingsB = trouverEquipeClassement(standings, fixture.equipeBId);

  const analyse = analyserMatch({
    fixture,
    statsA,
    statsB,
    lastFixturesA: exclureMatchCourant(lastFixturesA),
    lastFixturesB: exclureMatchCourant(lastFixturesB),
    h2h,
    blessuresA,
    blessuresB,
    standingsA,
    standingsB,
  });

  return { fixture, analyse };
}

function trouverEquipeClassement(standings, teamId) {
  if (!standings) return null;
  return standings.find((e) => e.team?.id === teamId) || null;
}

async function essayer(fn, valeurParDefaut = null) {
  try {
    return await fn();
  } catch {
    return valeurParDefaut;
  }
}

function repondreErreur(res, err) {
  if (err instanceof ErreurApiSportive) {
    const statutHttp = err.type === "quota_depasse" ? 429 : err.type === "cle_invalide" || err.type === "cle_absente" ? 401 : 502;
    return res.status(statutHttp).json({ erreur: err.message, typeErreur: err.type });
  }
  res.status(502).json({ erreur: err.message, typeErreur: "inconnue" });
}
