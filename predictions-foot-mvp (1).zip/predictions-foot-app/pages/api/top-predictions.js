// Cette route analyse TOUS les matchs d'une date pour en tirer un classement.
// Elle n'est jamais appelée automatiquement par la page d'accueil : c'est
// l'utilisateur qui déclenche ce bouton en connaissance de cause, car cela
// consomme un nombre d'appels API proportionnel au nombre de matchs du jour.

const { ErreurApiSportive, getFixturesByDate } = require("../../lib/apiFootball");
const { meilleureOpportunite } = require("../../lib/predictionEngine");
const cache = require("../../lib/cache");

const TTL_10_MIN = 10 * 60 * 1000;
const MAX_MATCHS_ANALYSES = 15; // garde-fou : au-delà, on analyse seulement les N premiers et on le signale

export default async function handler(req, res) {
  const { date } = req.query;
  if (!date) return res.status(400).json({ erreur: "Le paramètre 'date' est requis." });

  try {
    const { data: fixtures } = await cache.wrap(`matchs:${date}`, TTL_10_MIN, () => getFixturesByDate(date));

    if (fixtures.length === 0) {
      return res.status(200).json({ date, classement: [], message: "Aucun match ce jour-là." });
    }

    const restants = cache.appelsRestants();
    // Chaque match analysé consomme jusqu'à 5 appels (stats x2, derniers matchs x2, h2h, blessures, classement partagé)
    const budgetParMatch = 6;
    const analysablesParQuota = Math.floor(restants / budgetParMatch);
    const limite = Math.max(0, Math.min(MAX_MATCHS_ANALYSES, fixtures.length, analysablesParQuota));

    if (limite === 0) {
      return res.status(429).json({
        erreur: "Quota API insuffisant pour lancer une analyse groupée maintenant.",
        typeErreur: "quota_depasse",
        appelsRestants: restants,
      });
    }

    const aAnalyser = fixtures.slice(0, limite);
    const resultats = [];

    // Analyses en série (pas en parallèle) pour rester sous le débit
    // recommandé par l'API et ne pas déclencher de limitation agressive.
    for (const f of aAnalyser) {
      try {
        const reponse = await fetch(
          `${baseUrl(req)}/api/match-analysis?fixtureId=${f.fixture.id}`
        );
        const json = await reponse.json();
        if (reponse.status === 429) break; // quota atteint en cours de route : on s'arrête proprement
        if (reponse.ok && json.analyse) {
          resultats.push({
            fixtureId: f.fixture.id,
            equipeA: f.teams.home.name,
            equipeB: f.teams.away.name,
            competition: f.league?.name,
            date: f.fixture.date,
            analyse: json.analyse,
          });
        }
      } catch {
        // un match qui échoue n'interrompt pas le classement des autres
      }
    }

    const classement = classerOpportunites(resultats);

    res.status(200).json({
      date,
      matchsAnalyses: resultats.length,
      matchsIgnores: fixtures.length - aAnalyser.length,
      appelsRestantsApres: cache.appelsRestants(),
      classement,
    });
  } catch (err) {
    if (err instanceof ErreurApiSportive) {
      const statutHttp = err.type === "quota_depasse" ? 429 : 502;
      return res.status(statutHttp).json({ erreur: err.message, typeErreur: err.type });
    }
    res.status(502).json({ erreur: err.message, typeErreur: "inconnue" });
  }
}

// Construit une URL absolue pour s'appeler soi-même en interne (réutilise le
// même cache que la page détail : un match n'est jamais analysé deux fois).
function baseUrl(req) {
  const protocole = req.headers["x-forwarded-proto"] || "http";
  return `${protocole}://${req.headers.host}`;
}

// Classement cohérent : pour chaque match, on retient sa MEILLEURE opportunité
// (l'issue la plus probable parmi 1X2 / over-under / BTTS), puis on trie par
// un score qui combine probabilité ET confiance — pas la probabilité brute
// seule, pour éviter de mettre en avant un pari à 90% mais sans aucune donnée fiable.
function classerOpportunites(resultats) {
  const opportunites = resultats.map(({ fixtureId, equipeA, equipeB, competition, date, analyse }) => {
    const meilleure = meilleureOpportunite(analyse, equipeA, equipeB);

    return {
      fixtureId,
      equipeA,
      equipeB,
      competition,
      date,
      predictionRetenue: meilleure.libelle,
      probabilite: meilleure.probabilite,
      confiance: analyse.confiance,
      niveauConfiance: analyse.niveauConfiance,
      // Score de classement : la probabilité pèse plus que la confiance, mais
      // une opportunité à forte probabilité et faible confiance descend au classement.
      scoreClassement: meilleure.probabilite * 0.7 + analyse.confiance * 0.3,
    };
  });

  return opportunites.sort((a, b) => b.scoreClassement - a.scoreClassement);
}
