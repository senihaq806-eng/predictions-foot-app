const { ErreurApiSportive, getFixturesByDate } = require("../../lib/apiFootball");
const cache = require("../../lib/cache");

const TTL_10_MIN = 10 * 60 * 1000;

export default async function handler(req, res) {
  const { date } = req.query;
  if (!date) {
    return res.status(400).json({ erreur: "Le paramètre 'date' est requis (format YYYY-MM-DD)." });
  }

  try {
    const { data: fixtures, depuisCache } = await cache.wrap(
      `matchs:${date}`,
      TTL_10_MIN,
      () => getFixturesByDate(date)
    );

    const matchs = fixtures.map((f) => ({
      id: f.fixture.id,
      date: f.fixture.date,
      statut: f.fixture.status?.long,
      stade: f.fixture.venue?.name || null,
      competition: f.league?.name,
      pays: f.league?.country,
      equipeA: f.teams.home.name,
      equipeAId: f.teams.home.id,
      equipeB: f.teams.away.name,
      equipeBId: f.teams.away.id,
      leagueId: f.league?.id,
      season: f.league?.season,
    }));

    res.status(200).json({ date, nombre: matchs.length, depuisCache, matchs });
  } catch (err) {
    if (err instanceof ErreurApiSportive) {
      const statutHttp = err.type === "quota_depasse" ? 429 : err.type.startsWith("cle_") ? 401 : 502;
      return res.status(statutHttp).json({ erreur: err.message, typeErreur: err.type });
    }
    res.status(502).json({ erreur: err.message, typeErreur: "inconnue" });
  }
}
