const { getFixtureById } = require("../../lib/apiFootball");

export default async function handler(req, res) {
  const { fixtureId } = req.query;
  if (!fixtureId) return res.status(400).json({ erreur: "fixtureId requis" });

  try {
    const f = await getFixtureById(fixtureId);
    if (!f) return res.status(404).json({ erreur: "Match introuvable" });

    const termine = ["FT", "AET", "PEN"].includes(f.fixture.status?.short);
    if (!termine) {
      return res.status(200).json({ termine: false });
    }

    const butsA = f.goals.home;
    const butsB = f.goals.away;
    const issue = butsA > butsB ? "domicile" : butsA < butsB ? "exterieur" : "nul";

    res.status(200).json({ termine: true, butsA, butsB, issue });
  } catch (err) {
    res.status(502).json({ erreur: err.message });
  }
}
